import React, { useEffect, useState } from 'react'
import styled from 'styled-components'
import axios from 'axios';
import { API_KEY } from './Home'
import { IoMdClose } from 'react-icons/io'
import { useParams, Link } from 'react-router-dom';


const Container = styled.div`
    display: flex;
    flex-direction: row;
    padding: 20px 30px;
    justify-content: center;
    border-bottom: 1px solid #0b0000;
    background: rgb(120,9,9);
    background: linear-gradient(0deg, rgba(120,9,9,1) 0%, rgba(11,0,0,1) 55%);
`;
const MoviePoster = styled.img`
    height: 352px;
    object-fit: cover;
`;
const InfoColumn = styled.div`
    display: flex;
    flex-direction: row;
    justify-content: space-between;
`;
const MovieTitle = styled.span`
    font-size: 18px;
    font-weight: 600;
    color: white;
    margin: 15px 0;
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
`;
const MovieInfo = styled.span`
    font-size: 16px;
    font-weight: 500;
    color: white;
    margin: 4px 0;
    text-overflow: ellipsis;
    overflow: hidden;
    text-transform: capitalize;
    & span{
        opacity: 0.5;
    }
`;
const CloseInfo = styled.span`
    font-size: 16px;
    font-weight: 600;
    color: white;
    background-color: #df0707;
    height: fit-content;
    padding: 8px;
    border-radius: 50%;
    cursor: pointer;
    opacity: 0.8;
`;

const MoviesInfo = (props) => {

    const [movieInfo, setMovieInfo] = useState();
    const { selectMovie } = props
    const { id } = useParams();

    useEffect(() => {
        console.log(id)
        axios.get(`https://www.omdbapi.com/?i=${id}&apikey=${API_KEY}`)
            .then((response) => {
                setMovieInfo(response.data)
            })
    }, [selectMovie])

    return (
        <Container>
            {movieInfo ? <>
                <MoviePoster src={movieInfo?.Poster} />
                <InfoColumn>
                    <MovieTitle>
                        {movieInfo?.Type} : <span>{movieInfo?.Title}</span>
                    </MovieTitle>
                    <MovieInfo>
                        Year: <span>{movieInfo?.Year}</span>
                    </MovieInfo>
                    <MovieInfo>
                        Rated: <span>{movieInfo?.Rated}</span>
                    </MovieInfo>
                    <MovieInfo>
                        imdbRating: <span>{movieInfo?.imdbRating}</span>
                    </MovieInfo>
                    <MovieInfo>
                        Released: <span>{movieInfo?.Released}</span>
                    </MovieInfo>
                    <MovieInfo>
                        Runtime: <span>{movieInfo?.Runtime}</span>
                    </MovieInfo>
                    <MovieInfo>
                        Genre: <span>{movieInfo?.Genre}</span>
                    </MovieInfo>
                    <MovieInfo>
                        Director: <span>{movieInfo?.Director}</span>
                    </MovieInfo>
                    <MovieInfo>
                        Writer: <span>{movieInfo?.Writer}</span>
                    </MovieInfo>
                    <MovieInfo>
                        Actors: <span>{movieInfo?.Actors}</span>
                    </MovieInfo>
                    <MovieInfo>
                        Plot: <span>{movieInfo?.Plot}</span>
                    </MovieInfo>
                </InfoColumn>

            </> : "Loading..."}
        </Container>
    )
}

export default MoviesInfo