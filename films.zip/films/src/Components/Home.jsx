import React, { useState } from 'react';
import styled from 'styled-components';
import { MdLocalMovies } from 'react-icons/md'
import { BsSearch } from 'react-icons/bs'
import Movies from './Movies';
import axios from 'axios';
import MoviesInfo from './MoviesInfo';

export const API_KEY = '53d2d914'

const Container = styled.div`
  display: flex;
  flex-direction: column;
`;
const Header = styled.header`
  display: flex;
  flex-direction: row;
  background-color: #0b0000;
  justify-content: space-between;
  align-items: center;
  color: #980a0a;
  padding: 10px;
  font-family: 'Bebas Neue', cursive;
`;
const AppName = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
`;
const Search = styled.div`
  display: flex;
  flex-direction: row;
  padding: 10px 10px;
  background-color: white;
  border-radius: 6px;
  margin-left: 20px;
  width: 50%;
  justify-content: center;
  align-items: center;
`;
const SearchInput = styled.input`
  color: black;
  font-size: 16px;
  font-weight: bold;
  border: none;
  outline: none;
  margin-left: 15px;
`;
const MovieListContainer = styled.div`
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  padding: 30px;
  gap: 24px;
  justify-content: space-evenly;
`;
const HomePlaceholder = styled.img`
    width: 120px;
    height: 120px;
    margin: 150px;
    opacity: 50%;
`;
const SearchIcon = styled.div``;

function Home() {

  const [searchQuery, updateSearchQuery] = useState();
  const [timeoutId, updateTimeoutId] = useState();
  const [movieList, updateMovieList] = useState([]);
  const [selectMovie, onSelectMovie] = useState("");

  const fetchData = async (searchString) => {
    const response = await axios.get(`https://www.omdbapi.com/?s=${searchString}&apikey=${API_KEY}`)
    updateMovieList(response.data.Search)

  }

  const onTextChange = (event) => {

    clearTimeout(timeoutId)
    updateSearchQuery(event.target.value);
    console.log(searchQuery);
    const timeout = setTimeout(() => fetchData(event.target.value), 500)
    updateTimeoutId(timeout)
  }

  return (
    <Container>
      <Header>
        <AppName>Film List<MdLocalMovies style={{ 'color': '#980a0a' }} /></AppName>
        <Search>
          <SearchInput placeholder='Search Movie' value={searchQuery} onChange={onTextChange} />
          <SearchIcon><BsSearch /></SearchIcon>
        </Search>
      </Header>
      {selectMovie && <MoviesInfo selectMovie={selectMovie} onSelectMovie={selectMovie} />}
      <MovieListContainer>
        {movieList?.length ?
          movieList.map((movie, index) =>
            <Movies key={index} movie={movie} />) : <HomePlaceholder src='../../public/placeholder.png' />}

      </MovieListContainer>
    </Container>
  );
}

export default Home;